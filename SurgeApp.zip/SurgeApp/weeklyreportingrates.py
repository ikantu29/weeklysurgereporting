import dash
from dash import dcc, html, Output, Input, dash_table
import pandas as pd
import plotly.express as px
import os

# File paths
WEEKLY_TREND_FILE = r"C:\Users\Dell\Desktop\PIRS REPORTS\Weekly surge tracking\SurgeApp\Sample visual.xlsx"
FACILITY_FILE = r"C:\Users\Dell\Desktop\PIRS REPORTS\Weekly surge tracking\SurgeApp\Surge Facilities reporting.xlsx"

# Load weekly trend data
def load_weekly_data():
    if os.path.exists(WEEKLY_TREND_FILE):
        df = pd.read_excel(WEEKLY_TREND_FILE, sheet_name='Sheet1')
        df_melted = df.melt(
            id_vars=["district"],
            value_vars=df.columns[3:],
            var_name="Week",
            value_name="Reporting Rate"
        )
        df_grouped = df_melted.groupby("Week")["Reporting Rate"].mean().reset_index()
        df_grouped["Week"] = pd.Categorical(df_grouped["Week"], categories=df.columns[3:], ordered=True)
        df_grouped = df_grouped.sort_values("Week")
        df_grouped["Reporting Rate"] *= 100
        return df_grouped
    return pd.DataFrame(columns=["Week", "Reporting Rate"])

# Load facility reporting data
def load_facility_data():
    if os.path.exists(FACILITY_FILE):
        df = pd.read_excel(FACILITY_FILE, sheet_name='Sheet1')
        df['% surge reported'] = (df['% surge reported'] * 100).round(1)
        return df
    return pd.DataFrame(columns=["district", "Outlet", "% surge reported"])

# Initialize Dash app
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("UEC UCMB West Nile Weekly Reporting Status", style={
        'textAlign': 'center', 'color': '#003366', 'marginBottom': '20px'
    }),

    html.Div([
        html.Button("Refresh Data", id="refresh-button", n_clicks=0, style={
            'backgroundColor': '#007bff', 'color': 'white', 'padding': '8px 16px',
            'border': 'none', 'borderRadius': '4px', 'cursor': 'pointer',
            'marginBottom': '20px'
        }),
        dcc.Graph(id="trend-graph", config={'displayModeBar': False}),
    ], style={'padding': '0 40px'}),

    html.H2("Facility Surge Reporting Status", style={
        'textAlign': 'center', 'color': '#003366', 'marginTop': '40px'
    }),

    html.Div([
        dash_table.DataTable(
            id='facility-table',
            style_table={'overflowX': 'auto'},
            style_cell={
                'textAlign': 'left',
                'padding': '8px',
                'fontFamily': 'Arial, sans-serif',
                'fontSize': '14px'
            },
            style_header={
                'backgroundColor': '#003366',
                'color': 'white',
                'fontWeight': 'bold'
            },
            style_data_conditional=[],
        )
    ], style={'padding': '0 40px', 'marginBottom': '40px'})
], style={
    'backgroundColor': '#f8f9fa',
    'fontFamily': 'Segoe UI, sans-serif',
    'paddingTop': '20px'
})


@app.callback(
    [Output("trend-graph", "figure"),
     Output("facility-table", "data"),
     Output("facility-table", "columns"),
     Output("facility-table", "style_data_conditional")],
    [Input("refresh-button", "n_clicks")]
)
def update_outputs(n_clicks):
    # Load data
    df_trend = load_weekly_data()
    df_facilities = load_facility_data()

    # Create line chart
    fig = px.line(df_trend, x="Week", y="Reporting Rate", markers=True, title="Trend of Weekly Surge Reporting Rates (%)")
    fig.update_layout(
        plot_bgcolor='white',
        paper_bgcolor='white',
        font=dict(color='#333', size=14),
        title_x=0.5,
        margin=dict(t=40, b=40, l=40, r=40),
        hovermode='x unified'
    )
    fig.update_traces(line=dict(color='#007bff', width=2), marker=dict(size=6))
    fig.update_yaxes(showgrid=True, gridcolor='#ddd')
    fig.update_xaxes(showgrid=False)

    # Format table
    columns = [{"name": col.replace('_', ' ').title(), "id": col} for col in df_facilities.columns]
    style_data_conditional = [
        {
            'if': {'filter_query': '{% surge reported} >= 95', 'column_id': '% surge reported'},
            'backgroundColor': '#00b050', 'color': 'white'
        },
        {
            'if': {'filter_query': '{% surge reported} >= 90 && {% surge reported} < 95', 'column_id': '% surge reported'},
            'backgroundColor': '#ffc000', 'color': 'black'
        },
        {
            'if': {'filter_query': '{% surge reported} < 90', 'column_id': '% surge reported'},
            'backgroundColor': '#ff0000', 'color': 'white'
        }
    ]

    return (
        fig,
        df_facilities.to_dict('records'),
        columns,
        style_data_conditional
    )

if __name__ == "__main__":
    app.run_server(debug=True)
